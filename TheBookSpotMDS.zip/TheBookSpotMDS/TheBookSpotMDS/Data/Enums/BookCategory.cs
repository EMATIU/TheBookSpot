﻿namespace TheBookSpotMDS.Data.Enums
{
    public enum BookCategory
    {
        Action = 1,
        Drama = 2,
        SF = 3,
        Bestseller = 4,
        Classics = 5,
        Historical_Literature = 6
    }
}
